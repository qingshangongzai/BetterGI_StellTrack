# script_manager.py
import os
import json
from datetime import datetime
from PyQt6.QtWidgets import QFileDialog, QMessageBox
from PyQt6.QtGui import QDesktopServices

# 导入共享模块
from styles import StyleHelper, ChineseMessageBox
from utils import VK_MAPPING, KEY_NAME_MAPPING, EVENT_TYPE_MAP, convert_event_type_str_to_num, convert_event_type_num_to_str, get_key_chinese_name, get_event_data_from_table
from debug_tools import get_global_debug_logger

# =============================================================================
# 脚本管理类
# =============================================================================

class ScriptManager:
    """脚本管理类，负责所有与脚本生成和管理相关的操作"""
    
    def __init__(self, main_window):
        self.main_window = main_window
        self.debug_logger = get_global_debug_logger()
        self.script = None  # 存储生成的脚本
    
    def on_generate_script(self):
        """生成脚本"""
        try:
            self.debug_logger.log_info("开始生成脚本...")
            
            # 检查事件成对性
            if not self.check_event_pairing():
                # 如果成对性检查失败，直接返回
                self.debug_logger.log_warning("事件成对性检查失败，脚本生成取消")
                return
            
            # 收集事件数据
            events = []
            event_manager = self.main_window.event_manager
            for row in range(event_manager.events_table.rowCount()):
                event_data = get_event_data_from_table(event_manager.events_table, row)
                
                if event_data[0]:  # 如果事件名称不为空
                    # 转换为脚本格式
                    event_type_num = convert_event_type_str_to_num(event_data[1])
                    script_event = {
                        "type": event_type_num,
                        "mouseX": int(event_data[3]) if event_data[3] else 0,
                        "mouseY": int(event_data[4]) if event_data[4] else 0,
                        "time": int(event_data[6]) if event_data[6] else 0  # 使用绝对偏移时间
                    }
                    
                    # 如果是键盘事件，添加keyCode
                    if event_data[1] in ["按键按下", "按键释放"] and event_data[2]:
                        script_event["keyCode"] = int(event_data[2])
                    
                    # 如果是鼠标点击事件，添加mouseButton
                    if event_data[1] in ["左键按下", "左键释放"]:
                        script_event["mouseButton"] = "Left"
                    elif event_data[1] in ["右键按下", "右键释放"]:
                        script_event["mouseButton"] = "Right"
                    
                    events.append(script_event)
            
            if not events:
                self.debug_logger.log_warning("没有事件可生成脚本")
                ChineseMessageBox.show_warning(self.main_window, "警告", "没有事件可生成脚本")
                return
            
            # 获取循环次数
            loop_count = self.main_window.settings_panel.get_safe_loop_count()
            
            # 获取间隔时间
            interval = self.main_window.settings_panel.interval_input.value()
            
            # 转换时间单位为毫秒
            time_unit = self.main_window.settings_panel.time_unit_combo.currentText()
            if time_unit == "s":
                interval_ms = int(interval * 1000)
            elif time_unit == "min":
                interval_ms = int(interval * 60000)
            else:  # ms
                interval_ms = int(interval)
            
            # 生成完整的事件序列（考虑循环）
            full_events = []
            last_event_time = 0
            
            for loop in range(loop_count):
                for i, event in enumerate(events):
                    # 复制事件
                    new_event = event.copy()
                    
                    # 确保时间值为整数
                    event_time = int(event["time"])
                    
                    # 如果是第一个循环，使用原始时间
                    if loop == 0:
                        new_event["time"] = event_time
                    else:
                        # 后续循环：时间 = 原始时间 + (循环索引 * (最后一个事件时间 + 间隔时间))
                        new_event["time"] = event_time + loop * (last_event_time + interval_ms)
                    
                    full_events.append(new_event)
                
                # 更新最后一个事件的时间
                if events:
                    last_event_time = int(events[-1]["time"])
            
            # 获取缩放比例并转换为小数
            scale_str = self.main_window.settings_panel.scale_combo.currentText()
            try:
                record_dpi = float(scale_str.strip('%')) / 100.0
            except ValueError:
                record_dpi = 1.0  # 如果转换失败，使用默认值1.0
            
            # 获取应用信息用于脚本描述
            from utils import get_current_app_info
            app_info = get_current_app_info()
            
            # 脚本结构
            self.script = {
                "macroEvents": full_events,
                "info": {
                    "description": "由BetterGI StellTrack创建",
                    "x": 0,
                    "y": 0,
                    "width": int(self.main_window.settings_panel.width_input.text()),
                    "height": int(self.main_window.settings_panel.height_input.text()),
                    "recordDpi": record_dpi
                }
            }
            
            # 同时存储到主窗口，以便预览功能使用
            self.main_window.script = self.script
            
            # 生成默认文件名
            timestamp = datetime.now().strftime("%Y%m%d%H%M%S%f")[:-3]
            default_filename = f"BetterGI_GCM_{timestamp}.json"
            
            # 更新统计信息
            self.main_window.stats_panel.update_stats()
            
            self.main_window.status_bar.showMessage("✅ 脚本生成成功")
            self.debug_logger.log_info(f"脚本生成成功: {len(full_events)} 个事件, {loop_count} 次循环")
            ChineseMessageBox.show_info(self.main_window, "成功", f"脚本已成功生成！\n包含 {len(full_events)} 个事件 ({loop_count} 次循环)\n文件名: {default_filename}")
            
        except Exception as e:
            error_msg = f"生成脚本失败: {str(e)}"
            self.debug_logger.log_error(error_msg, exc_info=True)
            ChineseMessageBox.show_error(self.main_window, "错误", error_msg)
    
    def check_event_pairing(self):
        """检查事件成对性"""
        pressed_keys = set()  # 记录按下的按键
        pressed_mouse_buttons = set()  # 记录按下的鼠标按钮
        issues = []
        
        event_manager = self.main_window.event_manager
        
        for row in range(event_manager.events_table.rowCount()):
            type_item = event_manager.events_table.item(row, 2)  # 事件类型列
            keycode_item = event_manager.events_table.item(row, 3)  # 键码列
            
            if not type_item:
                continue
                
            event_type = type_item.text()
            keycode = keycode_item.text() if keycode_item else ""
            
            # 检查按键事件
            if event_type == "按键按下":
                if keycode in pressed_keys:
                    # 获取按键的中文名称
                    key_name_cn = get_key_chinese_name(keycode)
                    issues.append(f"第{row+1}行: 按键{key_name_cn}重复按下")
                else:
                    pressed_keys.add(keycode)
            elif event_type == "按键释放":
                if keycode not in pressed_keys:
                    # 获取按键的中文名称
                    key_name_cn = get_key_chinese_name(keycode)
                    issues.append(f"第{row+1}行: 按键{key_name_cn}未按下就释放")
                else:
                    pressed_keys.remove(keycode)
            
            # 检查鼠标事件
            elif event_type == "左键按下":
                if "Left" in pressed_mouse_buttons:
                    issues.append(f"第{row+1}行: 左键重复按下")
                else:
                    pressed_mouse_buttons.add("Left")
            elif event_type == "左键释放":
                if "Left" not in pressed_mouse_buttons:
                    issues.append(f"第{row+1}行: 左键未按下就释放")
                else:
                    pressed_mouse_buttons.remove("Left")
                    
            elif event_type == "右键按下":
                if "Right" in pressed_mouse_buttons:
                    issues.append(f"第{row+1}行: 右键重复按下")
                else:
                    pressed_mouse_buttons.add("Right")
            elif event_type == "右键释放":
                if "Right" not in pressed_mouse_buttons:
                    issues.append(f"第{row+1}行: 右键未按下就释放")
                else:
                    pressed_mouse_buttons.remove("Right")
                    
            elif event_type == "中键按下":
                if "Middle" in pressed_mouse_buttons:
                    issues.append(f"第{row+1}行: 中键重复按下")
                else:
                    pressed_mouse_buttons.add("Middle")
            elif event_type == "中键释放":
                if "Middle" not in pressed_mouse_buttons:
                    issues.append(f"第{row+1}行: 中键未按下就释放")
                else:
                    pressed_mouse_buttons.remove("Middle")
        
        # 检查未释放的按键
        for key in pressed_keys:
            key_name_cn = get_key_chinese_name(key)
            issues.append(f"按键{key_name_cn}被按下但未释放")
        for button in pressed_mouse_buttons:
            button_name = "左键" if button == "Left" else "右键" if button == "Right" else "中键"
            issues.append(f"鼠标{button_name}按钮被按下但未释放")
        
        if issues:
            # 显示详细的问题信息，并询问是否继续
            message = "检测到以下事件成对性问题：\n\n" + "\n".join(issues) + "\n\n是否继续生成脚本？"
            self.debug_logger.log_warning(f"事件成对性问题: {issues}")
            return ChineseMessageBox.show_question(self.main_window, "事件成对性检查", message)
        
        self.debug_logger.log_info("事件成对性检查通过")
        return True
    

    
    def on_save_script(self):
        """保存脚本"""
        try:
            if not self.script:
                self.debug_logger.log_warning("尝试保存但未生成脚本")
                ChineseMessageBox.show_warning(self.main_window, "警告", "请先生成脚本")
                return
            
            # 生成默认文件名
            timestamp = datetime.now().strftime("%Y%m%d%H%M%S%f")[:-3]
            default_filename = f"BetterGI_GCM_{timestamp}.json"
            
            filename, _ = QFileDialog.getSaveFileName(
                self.main_window,
                "保存脚本",
                default_filename,
                "JSON文件 (*.json);;所有文件 (*.*)"
            )
            
            if not filename:
                self.debug_logger.log_info("用户取消保存脚本")
                return
            
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(self.script, f, ensure_ascii=False, separators=(',', ':'))
            
            self.main_window.status_bar.showMessage(f"✅ 脚本已保存到: {filename}")
            self.debug_logger.log_info(f"脚本已保存到: {filename}")
            ChineseMessageBox.show_info(self.main_window, "成功", f"脚本已保存到:\n{filename}")
            
        except Exception as e:
            error_msg = f"保存脚本失败: {str(e)}"
            self.debug_logger.log_error(error_msg, exc_info=True)
            ChineseMessageBox.show_error(self.main_window, "错误", error_msg)
    
    def on_import_script(self):
        """导入脚本"""
        try:
            # 打开文件对话框选择要导入的脚本文件
            filename, _ = QFileDialog.getOpenFileName(
                self.main_window,
                "导入脚本",
                "",
                "JSON文件 (*.json);;所有文件 (*.*)"
            )
            
            if not filename:
                self.debug_logger.log_info("用户取消导入脚本")
                return
            
            # 读取并解析脚本文件
            with open(filename, 'r', encoding='utf-8') as f:
                script_data = json.load(f)
            
            # 检查脚本格式是否正确
            if "macroEvents" not in script_data:
                ChineseMessageBox.show_error(self.main_window, "错误", "无效的脚本格式: 缺少macroEvents字段")
                return
            
            # 清空当前事件
            event_manager = self.main_window.event_manager
            event_manager.events_table.setRowCount(0)
            
            # 重置搜索筛选条件，确保导入的事件都能显示出来
            event_manager.on_reset_search_filter()
            
            # 保存当前状态到撤销栈
            self.main_window.save_state_to_undo_stack()
            
            # 开始批量操作
            self.main_window._batch_operation = True
            
            try:
                # 导入事件
                for i, event in enumerate(script_data["macroEvents"]):
                    # 转换事件类型
                    event_type = convert_event_type_num_to_str(event["type"])
                    
                    # 获取事件数据
                    keycode = str(event.get("keyCode", "")) if event_type in ["按键按下", "按键释放"] else ""
                    mouse_x = str(event.get("mouseX", 0))
                    mouse_y = str(event.get("mouseY", 0))
                    time = str(event.get("time", 0))
                    
                    # 生成事件名称
                    from utils import generate_key_event_name
                    event_name = generate_key_event_name(event_type, keycode)
                    
                    # 添加到表格
                    event_data = [
                        str(i + 1),  # 行号
                        event_name,  # 事件名称
                        event_type,  # 事件类型
                        keycode,  # 键码
                        mouse_x,  # X坐标
                        mouse_y,  # Y坐标
                        "0",  # 相对偏移（将在后续重新计算）
                        time  # 绝对偏移
                    ]
                    
                    event_manager.add_table_row(event_data)
                
                # 重新计算相对时间
                event_manager.recalculate_relative_times()
                
                # 更新行号
                event_manager.update_row_numbers()
                
                # 更新统计信息
                event_manager.update_stats()
                
                # 标记状态变更
                self.main_window.mark_state_dirty()
                
                self.main_window.status_bar.showMessage("✅ 脚本导入成功")
                self.debug_logger.log_info(f"脚本导入成功: {filename}")
                ChineseMessageBox.show_info(self.main_window, "成功", f"脚本导入成功:\n{filename}")
                
                # 立即更新预计总时间
                self.main_window.on_calculate_total_time()
            finally:
                # 结束批量操作
                self.main_window._batch_operation = False
                
        except json.JSONDecodeError:
            self.debug_logger.log_error("导入脚本失败: JSON格式错误")
            ChineseMessageBox.show_error(self.main_window, "错误", "无效的JSON文件格式")
        except Exception as e:
            error_msg = f"导入脚本失败: {str(e)}"
            self.debug_logger.log_error(error_msg, exc_info=True)
            ChineseMessageBox.show_error(self.main_window, "错误", error_msg)
    

